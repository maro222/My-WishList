package com.mycompany.mywishlist;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import com.mycompany.model.Request;
import com.mycompany.model.Response;
import com.mycompany.model.User;
import com.mycompany.model.Item;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.List;

public class TestClient extends Thread{
    

    Socket socket;
    private ObjectInputStream in;
    private ObjectOutputStream out;
    private volatile boolean running = true;
    
    
    public TestClient(){
        try{
            socket = new Socket("127.0.0.1", 5005);
            out = new ObjectOutputStream(socket.getOutputStream());
            out.flush();
            in = new ObjectInputStream(socket.getInputStream());
        }catch (IOException e){
            closeEveryThing();
        }
    }
    
    @Override
    public void run(){
        
            listenToServer();
    }
    
    
    private void listenToServer() {
        try {
            while (running) {
                Response response = (Response) in.readObject();
                handleResponse(response);
            }
        } catch (Exception e) {
            System.out.println("Server disconnected");
            running = false;
        } finally {
            closeEveryThing();
        }
    }
    
    private void handleResponse(Response response) {
        System.out.println("Server: " + response.getMessage());

        // Later:
        // if(response.getType().equals("NOTIFICATION")) { ... }
    }

    public synchronized void send(Request request) throws Exception {     //specific button that should be implemented for others
        // request = fill data of fields as request
        if (socket == null || socket.isClosed()) {
            // Handle reconnection or throw an error if necessary
            throw new IllegalStateException("Socket is not connected.");
        }
        
        // Send the request object
        out.writeObject(request);
        out.flush();
    }
    
    
    public void closeEveryThing(){
        try{
            running = false;
            if (socket != null)
                socket.close();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}