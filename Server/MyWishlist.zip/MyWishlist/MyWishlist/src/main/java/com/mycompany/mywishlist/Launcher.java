package com.mycompany.mywishlist;

public class Launcher {
    public static void main(String[] args) {
        ServerApp.main(args);
    }
}