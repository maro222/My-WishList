/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mywishlist;

import java.util.Map;
import com.mycompany.model.Request;
import com.mycompany.model.User;

/**
 *
 * @author user
 */
public class Client {
    public static void main(String[] args) throws Exception {
    TestClient client = new TestClient();
    client.start(); // starts run()

    // simulate user actions
    client.send(new Request(
        "LOGIN",
        new User("Ayman", null ,"123456")
    ));
  }
}
