package com.mycompany.mywishlist;

import com.mycompany.model.Request;
import com.mycompany.model.User;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Map;

/**
 * JavaFX App
 */
public class App extends Application {

    private static Scene scene;
    private TestClient client;
        
    @Override
    public void start(Stage stage) throws IOException {
        scene = new Scene(loadFXML("primary"), 640, 480);
        stage.setScene(scene);
        stage.show();

        // --- FIX: Initialize Client HERE, not in main() ---
        startClientBackend();
    }

    private void startClientBackend() {
        // Run in a new thread so we don't block the UI
        new Thread(() -> {
            try {
                client = new TestClient();
                client.start();

                System.out.println("Client started, sending login request...");
                
                // Simulate user actions
                client.send(new Request(
                        "LOGIN",
                        new User("kahledTest", "khaled@iti", "123456")
                ));
            } catch (Exception e) {
                System.out.println("Client cannot login");
            }
        }).start();
    }

    @Override
    public void stop() throws Exception {
        // Best Practice: Close connection when app closes
        if (client != null) {
            client.closeEveryThing();
        }
        super.stop();
    }

    static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        // Only launch logic here. Everything else goes into start()
        launch(args);
    }

}