module com.mycompany.mywishlist {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.mycompany.mywishlist to javafx.fxml;
    exports com.mycompany.mywishlist;
}
